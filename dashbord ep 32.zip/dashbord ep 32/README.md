# Atmos Intelligence

Premium ESP32 weather dashboard with a Vite/React frontend and an optional Node MQTT-to-WebSocket bridge.

## Run locally

```bash
npm install
npm run dev
```

The dashboard opens in demo mode by default. Use the mode button in the header to make the production connection state explicit.

## Connect an ESP32

Start the bridge in a second terminal:

```bash
MQTT_URL=mqtt://localhost:1883 MQTT_TOPIC=esp32/weather npm run server
```

Or post sensor payloads directly:

```bash
curl -X POST http://localhost:8787/api/sensors -H "Content-Type: application/json" -d "{\"temperature\":25.4,\"humidity\":58,\"pressure\":1012,\"rain\":650,\"intensity\":2.4,\"raining\":true}"
```

The bridge validates numeric fields, stores the latest measurement in memory, and broadcasts updates to connected WebSocket clients. For production, replace the in-memory latest value with SQLite/PostgreSQL and put the bridge behind TLS/authentication.

## Build

```bash
npm run build
```

Open-Meteo forecast data is loaded from the browser for the Algiers default location. Move the latitude/longitude query into a settings store when adding multi-device location management.
