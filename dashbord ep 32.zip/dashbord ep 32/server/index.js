import express from 'express';
import cors from 'cors';
import { WebSocketServer } from 'ws';
import mqtt from 'mqtt';
import { createServer } from 'http';

const app = express(); app.use(cors()); app.use(express.json());
const server = createServer(app); const wss = new WebSocketServer({ server });
let latest = { temperature: 24.8, humidity: 61, pressure: 1014, rain: 18, intensity: 0, raining: false, updatedAt: new Date().toISOString() };
const clients = new Set();
const broadcast = payload => clients.forEach(ws => ws.readyState === 1 && ws.send(JSON.stringify(payload)));
wss.on('connection', ws => { clients.add(ws); ws.send(JSON.stringify({ type: 'sensor:update', data: latest })); ws.on('close', () => clients.delete(ws)); });
app.get('/api/health', (_, res) => res.json({ ok: true, clients: clients.size, latest }));
app.get('/api/sensors/latest', (_, res) => res.json(latest));
app.post('/api/sensors', (req, res) => { const body = req.body || {}; const numeric = ['temperature','humidity','pressure','rain','intensity']; for (const key of numeric) if (body[key] !== undefined && !Number.isFinite(Number(body[key]))) return res.status(400).json({ error: `${key} must be numeric` }); latest = { ...latest, ...body, updatedAt: new Date().toISOString() }; broadcast({ type: 'sensor:update', data: latest }); res.status(202).json(latest); });
const mqttUrl = process.env.MQTT_URL;
if (mqttUrl) { const client = mqtt.connect(mqttUrl, { username: process.env.MQTT_USER, password: process.env.MQTT_PASSWORD }); client.on('connect', () => client.subscribe(process.env.MQTT_TOPIC || 'esp32/weather')); client.on('message', (_, message) => { try { const data = JSON.parse(message.toString()); latest = { ...latest, ...data, updatedAt: new Date().toISOString() }; broadcast({ type: 'sensor:update', data: latest }); } catch {} }); }
const port = process.env.PORT || 8787; server.listen(port, () => console.log(`Weather bridge listening on http://localhost:${port}`));
